extends Node

const Unit = preload("res://battle/models/Unit.gd")

var rng := RandomNumberGenerator.new()
var rng_seed: int = 0
var current_hero_unit: Unit = null # New: Reference to the player's hero unit
var gold: int = 100 # Player's currency, starting with 100 for testing

func set_seed(new_seed: int) -> void:
	rng_seed = new_seed
	rng.seed = new_seed

func randf() -> float:
	return rng.randf()

func randi_range(a: int, b: int) -> int:
	return rng.randi_range(a, b)
